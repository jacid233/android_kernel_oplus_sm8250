#include "pch.h"
#include "Global.h"

CNetworkManager g_NetworkManager;