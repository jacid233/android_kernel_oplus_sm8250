#include "Global.h"
/*
std::map<HANDLE, HANDLE_INFO> g_HandlePointList;
*/
CHwBreakpointManager g_Driver;
