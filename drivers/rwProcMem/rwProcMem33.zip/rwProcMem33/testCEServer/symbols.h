#pragma once
class CSymbols {
public:
	//static int GetSymbolListFromFile(char *filename, unsigned char **output);
	//static unsigned long long GetModuleSize(char *filename, unsigned long long defaultsize);

};

